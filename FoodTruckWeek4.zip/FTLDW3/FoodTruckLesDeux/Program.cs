using FoodTruckLesDeux.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;

namespace FoodTruckLesDeux
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddDbContext<FoodTruckContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("FoodTruckLesDeuxConnection")));



            var app = builder.Build();
            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<FoodTruckContext>();
                if (!db.MenuItems.Any() && !db.Locations.Any())
                {
                    // Seed initial data compiler built this for me
                    db.MenuItems.AddRange(
                        new MenuItem { Name = "Taco", Price = 3.00M },
                        new MenuItem { Name = "Burrito", Price = 5.00M },
                        new MenuItem { Name = "Quesadilla", Price = 4.00M }
                    );
                    db.Locations.AddRange(
                        new Location { Name = "Downtown", Address = "123 Main St" },
                        new Location { Name = "Uptown", Address = "456 Elm St" }
                    );
                    db.SaveChanges();
                }
            }

                // Configure the HTTP request pipeline.
                if (!app.Environment.IsDevelopment())
                {
                    app.UseExceptionHandler("/Home/Error");
                    app.UseHsts();
                }

            app.UseHttpsRedirection();
            app.UseRouting();

            app.UseAuthorization();

            app.MapStaticAssets();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}")
                .WithStaticAssets();

            app.Run();
        }
    }
}
