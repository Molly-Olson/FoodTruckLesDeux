﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FoodTruckLesDeux.Migrations
{
    /// <inheritdoc />
    public partial class FinishedWeek3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
