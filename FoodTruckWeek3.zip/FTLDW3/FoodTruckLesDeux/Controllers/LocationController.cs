﻿using FoodTruckLesDeux.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodTruckLesDeux.Controllers
{
    public class LocationController : Controller
    {
        private readonly FoodTruckContext _context;
        public LocationController(FoodTruckContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var locations = _context.Locations.ToList();
            return View(locations);
        }
        [Route("Locations/Details")]
        public IActionResult Details()
        {
            return View();
        }
    }
}
