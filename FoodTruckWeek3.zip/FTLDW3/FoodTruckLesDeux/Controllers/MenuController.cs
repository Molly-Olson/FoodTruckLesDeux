﻿using FoodTruckLesDeux.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodTruckLesDeux.Controllers
{
    public class MenuController : Controller
    {
        private readonly FoodTruckContext _context;
        public MenuController(FoodTruckContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var menuItems = _context.MenuItems.ToList();
            return View(menuItems);
        }
        [Route("MenuItems/Info")]
        public IActionResult Details()
        {
            return View();
        }
    }
}
