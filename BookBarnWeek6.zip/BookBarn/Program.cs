using BookBarn.Models;
using BookBarn.Services;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddRazorPages();

builder.Services.AddDbContext<BookBarnContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("BookBarnConnection")));

builder.Services.AddIdentity<IdentityUser, IdentityRole>(options =>
{
    options.SignIn.RequireConfirmedAccount = false;
})
.AddEntityFrameworkStores<BookBarnContext>()
.AddDefaultTokenProviders();

builder.Services.AddTransient<IEmailSender, DevEmailSender>();

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<BookBarnContext>();

    if (!db.Books.Any())
    {         db.Books.AddRange(
            new Book { Title = "The Great Gatsby", Author = "F. Scott Fitzgerald", Price = 10.99M },
            new Book { Title = "1984", Author = "George Orwell", Price = 8.99M },
            new Book { Title = "To Kill a Mockingbird", Author = "Harper Lee", Price = 12.99M }
        );
        db.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
app.UseRouting();
    
app.UseAuthentication();
app.UseAuthorization();
app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.MapRazorPages();

using (var scope = app.Services.CreateScope())
{
    // ----------------------------------------
    // Seed BookBarn data (Books/Authors)
    // ----------------------------------------
    var db = scope.ServiceProvider.GetRequiredService<BookBarnContext>();
    if (!db.Books.Any()) {
        db.Books.AddRange(
            new Book { Title = "The Pragmatic Programmer", Author = "Hunt & Thomass", Price = 42.00m },
            new Book { Title = "Clean Code", Author = "Robert C. Martin", Price = 38.50m },
            new Book { Title = "Design Patterns", Author = "Gamma el al.", Price = 55.00m }
            );
        db.SaveChanges();
    }
    if (!db.Authors.Any())
    {
        db.Authors.AddRange(
            new Author { FirstName = "Robert", LastName = "Martin", MiddleName = "C. " },
            new Author { FirstName = "J.R.R.", LastName = "Tolkein", MiddleName = "" },
            new Author { FirstName = "J.K.", LastName = "Rowling", MiddleName = "" }
            );
        db.SaveChanges();
    }
    // ------------------------------------
    // Seed Identity (Admin role/user)
    // ------------------------------------
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

    if (!await roleManager.RoleExistsAsync("Admin"))
    {
        await roleManager.CreateAsync(new IdentityRole("Admin"));
    }

    var adminEmail = "admin@bookbarn.com";
    var adminUser = await userManager.FindByEmailAsync(adminEmail);
    
    if (adminUser == null)
    {
        adminUser = new IdentityUser
        {
            UserName = adminEmail,
            Email = adminEmail,
            EmailConfirmed = true
        };
        await userManager.CreateAsync(adminUser, "P@ssw0rd!");
    }
    if (!await userManager.IsInRoleAsync(adminUser, "Admin"))
    {
        await userManager.AddToRoleAsync(adminUser, "Admin");
    }
    // .WithStaticAssets();


    app.Run();
}