﻿using System.ComponentModel.DataAnnotations;

namespace BookBarn.Models
{
    public class CustomerContactModel
    {

        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(50)]
        public required string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        public required string LastName { get; set; }

        [Required]
        [EmailAddress]
        public required string Email { get; set; }

        [Required]
        [Phone]
        public required string PhoneNumber { get; set; }

        [Required]
        [StringLength(500)]
        public required string Message { get; set; }
    }
}
