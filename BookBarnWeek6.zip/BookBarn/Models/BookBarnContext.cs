﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using BookBarn.Models;

namespace BookBarn.Models
{
    public class BookBarnContext : IdentityDbContext
    {
        public BookBarnContext(DbContextOptions<BookBarnContext> options)
            : base(options)
        {
        }
        public DbSet<Book> Books => Set<Book>();
        public DbSet<Author> Authors => Set<Author>();
        public DbSet<BookBarn.Models.CustomerContactModel> CustomerContactModel { get; set; } = default!;
    }
}
