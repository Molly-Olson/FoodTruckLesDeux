﻿using System.ComponentModel.DataAnnotations;

namespace BookBarn.Models
{
    public class BookSuggestionModel
    {
        [Required]
        [StringLength(80)]
        public required string Title { get; set; }
       
        [Required]
        [StringLength(60)]
        public required string Author { get; set; }

        [Required]
        [Range(1, 5)]
        public required int Rating { get; set; }

        [StringLength(300)]
        public string? Notes { get; set; }
    }
}
