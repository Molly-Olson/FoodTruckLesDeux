﻿using Microsoft.AspNetCore.Mvc;
using BookBarn.Models;

namespace BookBarn.Controllers
{
    public class CustomerContactController : Controller
    {
        //GET: /CustomerContact/Create
        public IActionResult Create()
        {
            return View();
        }
        //POST: /CustomerContact/Create
        [HttpPost]
        public IActionResult Create(CustomerContactModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            //success logic will be expanded later
            return RedirectToAction("ThankYou");
        }
        //GET: /CustomerContact/ThankYou
        public IActionResult ThankYou()
        {
            return View();
        }
    }
}
