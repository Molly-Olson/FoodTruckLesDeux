﻿using BookBarn.Models;
using Microsoft.AspNetCore.Mvc;
using BookBarn.ViewModels;
using Microsoft.AspNetCore.Authorization;


namespace BookBarn.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookBarnContext _context;
        public BooksController(BookBarnContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var books = _context.Books.ToList();
            var vm = new BookListViewModel
            {
                Books = books,
                PageTitle = "Available Books",
                TotalCount = books.Count,
                EmptyMessage = "No books are currently available my G!"
            };
            return View(vm);
        }
        [Route("Books/Info")]
        public IActionResult About()
        {

            return View();
        }

            [Authorize(Roles = "Admin")]
            public IActionResult Manage()
            {
                return View();
            }
        }
    }

