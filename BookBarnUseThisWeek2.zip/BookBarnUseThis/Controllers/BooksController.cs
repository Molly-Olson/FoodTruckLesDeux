﻿using Microsoft.AspNetCore.Mvc;

namespace BookBarn.Controllers
{
    public class BooksController : Controller
    {
        [Route("About")]
        public IActionResult Index()
        {
            return View();
        }
        [Route("Books/Info")]
        public IActionResult About()
        {
            return View();
        }
    }
}
