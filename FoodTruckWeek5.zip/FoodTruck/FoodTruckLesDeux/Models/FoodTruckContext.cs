﻿using FoodTruckLesDeux.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;

namespace FoodTruckLesDeux.Models
{
    public class FoodTruckContext : DbContext
    {
        public FoodTruckContext(DbContextOptions<FoodTruckContext> options)
            : base(options)
        {
        }
        public DbSet<MenuItem> MenuItems => Set<MenuItem>();
        public DbSet<Location> Locations => Set<Location>();
    } }
