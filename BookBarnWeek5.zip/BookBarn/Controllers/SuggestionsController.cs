﻿using Microsoft.AspNetCore.Mvc;
using BookBarn.Models;
using Microsoft.Identity.Client;

namespace BookBarn.Controllers
{
    public class SuggestionsController : Controller
    {
        //GET: /Suggestions/Create
        public IActionResult Create()
        {
            return View();
        }

        //POST: /Suggestions/Create
        [HttpPost]
        public IActionResult Create(BookSuggestionModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            //success logic will be expanded later
            return RedirectToAction("ThankYou");
        }
        //GET: /Suggestions/ThankYou
        public IActionResult ThankYou()
        {
            return View();
        }
    }
}
    
