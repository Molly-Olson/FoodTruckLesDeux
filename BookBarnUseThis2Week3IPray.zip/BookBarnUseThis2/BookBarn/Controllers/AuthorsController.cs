﻿using Microsoft.AspNetCore.Mvc;

namespace BookBarn.Controllers
{
    public class AuthorsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        
        //optional create actions GET and POST 
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Post()
            {
            return View();
        }
    }
}
