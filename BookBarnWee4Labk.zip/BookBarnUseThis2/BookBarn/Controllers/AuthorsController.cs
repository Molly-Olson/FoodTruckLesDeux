﻿using BookBarn.Models;
using BookBarn.ViewModels;
using Microsoft.AspNetCore.Mvc;
using static System.Reflection.Metadata.BlobBuilder;

namespace BookBarn.Controllers
{
    public class AuthorsController : Controller
    {
        private readonly BookBarnContext context;
        public AuthorsController(BookBarnContext _context) {
           context = _context;
        }
        public IActionResult Index()
        {
            var authors = context.Authors.ToList();
            var vm = new AuthorListViewModel
            {
                Authors = authors,
                PageTitle = "Learn about our Authors!",
                TotalCount = authors.Count,
                EmptyMessage = "No Authors are currently registered, bummer dude!"

            };
            return View(vm);
        }
        
        //optional create actions GET and POST 
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Post()
            {
            return View();
        }
    }
}
